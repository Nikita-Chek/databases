create
    definer = root@localhost procedure insertRow(IN x varchar(20), IN y varchar(20), OUT id int)
begin 
    declare localId int;
    set localId = idgeerate();
    insert into test values 
    (localId, x,y);
    set id = localId;
end;

