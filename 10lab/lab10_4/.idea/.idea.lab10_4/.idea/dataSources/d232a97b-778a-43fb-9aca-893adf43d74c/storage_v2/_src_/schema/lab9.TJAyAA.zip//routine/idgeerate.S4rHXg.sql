create
    definer = root@localhost function idgeerate() returns int
begin 
    return floor(rand() * 90000 + 10000);
end;

