create
    definer = root@localhost procedure count_product(IN manufName varchar(20), INOUT o int)
begin 
    select count(product.id) into o from manufactory
        inner join product
            on manufactory.id = product.manuf_id
    where manufactory.name = manufName;
end;

