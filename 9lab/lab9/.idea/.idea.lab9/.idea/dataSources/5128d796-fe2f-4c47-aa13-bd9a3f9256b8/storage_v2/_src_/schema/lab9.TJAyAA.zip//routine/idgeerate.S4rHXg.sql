create
    definer = root@localhost function idgeerate() returns int deterministic
begin 
    return floor(rand() * 90000 + 10000);
end;

