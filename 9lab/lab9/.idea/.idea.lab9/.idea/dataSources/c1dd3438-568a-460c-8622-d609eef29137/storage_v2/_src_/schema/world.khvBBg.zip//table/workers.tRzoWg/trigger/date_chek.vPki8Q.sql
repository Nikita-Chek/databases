create definer = root@localhost trigger date_chek
    before insert
    on workers
    for each row
begin
	if replace(new.w_b, '-','') = replace(reverse(new.w_b), '-', '')
    then -- тут я просто реверсом проверяю на полиндром удаляя - тире
		signal sqlstate '45000';
	end if;
end;

