create view test as
select `t1`.`code` AS `code`, `t1`.`n1` AS `n1`, `t2`.`n2` AS `n2`
from ((select `world`.`countrylanguage`.`CountryCode` AS `code`, avg(`world`.`countrylanguage`.`Percentage`) AS `n1`
       from `world`.`countrylanguage`
       group by `world`.`countrylanguage`.`CountryCode`) `t1`
         join (select `world`.`city`.`CountryCode` AS `code`, count(`world`.`city`.`ID`) AS `n2`
               from `world`.`city`
               group by `world`.`city`.`CountryCode`) `t2` on ((`t2`.`code` = `t1`.`code`)))
where (`t1`.`n1` > `t2`.`n2`);

