create view country_1 as
select `world`.`country`.`Name` AS `name`, `world`.`country`.`Population` AS `population`
from `world`.`country`
where (`world`.`country`.`Population` > 10000000);

