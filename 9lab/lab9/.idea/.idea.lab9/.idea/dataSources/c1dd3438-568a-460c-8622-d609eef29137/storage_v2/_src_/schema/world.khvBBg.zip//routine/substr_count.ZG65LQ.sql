create
    definer = root@localhost function substr_count(s varchar(20), ss varchar(20)) returns tinyint(3)
begin
	declare count, len tinyint(3) default 0;
    set len = length(s);
    while len > 0 do
		set count = count + (substring(s, len, 1) regexp ss);
        set len = len - 1;
	end while;
return count;
end;

