create view capitals as
select `world`.`country`.`Name` AS `name`, `world`.`city`.`Name` AS `name`
from (`world`.`country`
         join `world`.`city` on ((`world`.`city`.`ID` = `world`.`country`.`Capital`)));

